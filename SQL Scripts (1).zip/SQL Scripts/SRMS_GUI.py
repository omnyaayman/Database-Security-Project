"""
Secure Student Records Management System (SRMS)
Complete Implementation with ALL Security Requirements
- Access Control (RBAC)
- Inference Control
- Flow Control with Export/Copy Prevention
- Multilevel Security (MLS)
- Encryption
- Role Request Workflow
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import pyodbc
from datetime import datetime
import logging

# Setup security audit logging
logging.basicConfig(
    filename='security_audit.log',
    level=logging.WARNING,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class DatabaseConnection:
    def __init__(self):
        self.connection_string = (
            "Driver={SQL Server};"
            "Server=MOHAMMED_SALAH;"
            "Database=SecureStudentRecords;"
            "Trusted_Connection=yes;"
        )
        self.connection = None
    
    def connect(self):
        try:
            self.connection = pyodbc.connect(self.connection_string)
            return True
        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect:\n{str(e)}")
            return False
    
    def execute_procedure(self, proc_name, params=None):
        try:
            cursor = self.connection.cursor()
            if params:
                placeholders = ', '.join(['?'] * len(params))
                query = f"EXEC {proc_name} {placeholders}"
                cursor.execute(query, params)
            else:
                cursor.execute(f"EXEC {proc_name}")
            
            try:
                results = cursor.fetchall()
                columns = [column[0] for column in cursor.description] if cursor.description else []
                cursor.commit()
                return results, columns
            except:
                cursor.commit()
                return [], []
        except Exception as e:
            return None, str(e)
    
    def execute_query(self, query):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
            columns = [column[0] for column in cursor.description] if cursor.description else []
            return results, columns
        except Exception as e:
            return None, str(e)
    
    def close(self):
        if self.connection:
            self.connection.close()


class SecureText(scrolledtext.ScrolledText):
    """Secured text widget that blocks copy/paste/export for classified data"""
    def __init__(self, parent, classification_level=1, **kwargs):
        super().__init__(parent, **kwargs)
        self.classification_level = classification_level
        
        # Block copy/paste/export for Secret (3) and Top Secret (4) data
        if classification_level >= 3:
            # Block all copy operations
            self.bind("<Control-c>", self._block_operation)
            self.bind("<Control-C>", self._block_operation)
            self.bind("<Control-x>", self._block_operation)
            self.bind("<Control-X>", self._block_operation)
            self.bind("<Control-v>", self._block_operation)
            self.bind("<Control-V>", self._block_operation)
            
            # Block print operations
            self.bind("<Control-p>", self._block_operation)
            self.bind("<Control-P>", self._block_operation)
            
            # Block save operations
            self.bind("<Control-s>", self._block_operation)
            self.bind("<Control-S>", self._block_operation)
            
            # Block select all (to prevent mass copying)
            self.bind("<Control-a>", self._block_operation)
            self.bind("<Control-A>", self._block_operation)
            
            # Block right-click context menu
            self.bind("<Button-3>", self._block_operation)
            
            # Disable export to clipboard
            self.config(exportselection=False)
            
            # Make read-only for maximum security
            self.config(state='disabled')
    
    def _block_operation(self, event=None):
        """Block operation and show warning"""
        # Log security violation
        logging.warning(f"BLOCKED: Copy/Export attempt on {self.get_classification_name()} data (SecureText widget)")
        
        messagebox.showwarning(
            "Operation Blocked",
            f"🔒 SECURITY RESTRICTION\n\n"
            f"This is {self.get_classification_name()} classified data.\n"
            f"Copying, exporting, saving, and printing are BLOCKED.\n\n"
            f"Classification Level: {self.classification_level}"
        )
        return "break"
    
    def get_classification_name(self):
        """Get classification level name"""
        names = {1: "UNCLASSIFIED", 2: "CONFIDENTIAL", 3: "SECRET", 4: "TOP SECRET"}
        return names.get(self.classification_level, "UNKNOWN")
    
    def insert_secure(self, index, text, *args):
        """Insert text into secure widget (temporarily enable, then disable)"""
        if self.classification_level >= 3:
            self.config(state='normal')
            self.insert(index, text, *args)
            self.config(state='disabled')
        else:
            self.insert(index, text, *args)


class SecureTreeview(ttk.Treeview):
    """Secured Treeview that blocks export/copy for classified data"""
    def __init__(self, parent, classification_level=1, **kwargs):
        super().__init__(parent, **kwargs)
        self.classification_level = classification_level
        
        # Block copy/export for Secret (3) and Top Secret (4) data
        if classification_level >= 3:
            # Block all copy operations
            self.bind("<Control-c>", self._block_operation)
            self.bind("<Control-C>", self._block_operation)
            self.bind("<Control-x>", self._block_operation)
            self.bind("<Control-X>", self._block_operation)
            
            # Block print operations
            self.bind("<Control-p>", self._block_operation)
            self.bind("<Control-P>", self._block_operation)
            
            # Block save operations
            self.bind("<Control-s>", self._block_operation)
            self.bind("<Control-S>", self._block_operation)
            
            # Block select all
            self.bind("<Control-a>", self._block_operation)
            self.bind("<Control-A>", self._block_operation)
            
            # Block right-click context menu
            self.bind("<Button-3>", self._block_operation)
            
            # Note: exportselection is not available for ttk.Treeview
            # Selection blocking is handled through event bindings
    
    def _block_operation(self, event=None):
        """Block operation and show warning"""
        # Log security violation
        logging.warning(f"BLOCKED: Copy/Export attempt on {self.get_classification_name()} data (SecureTreeview widget)")
        
        messagebox.showwarning(
            "Operation Blocked",
            f"🔒 SECURITY RESTRICTION\n\n"
            f"This is {self.get_classification_name()} classified data.\n"
            f"Copying, exporting, saving, and printing are BLOCKED.\n\n"
            f"Classification Level: {self.classification_level}\n"
            f"Data is visible but cannot be extracted from the system."
        )
        return "break"
    
    def get_classification_name(self):
        """Get classification level name"""
        names = {1: "UNCLASSIFIED", 2: "CONFIDENTIAL", 3: "SECRET", 4: "TOP SECRET"}
        return names.get(self.classification_level, "UNKNOWN")


class LoginWindow:
    def __init__(self, root, db, on_login_success):
        self.root = root
        self.db = db
        self.on_login_success = on_login_success
        
        self.root.title("SRMS - Secure Login")
        self.root.geometry("550x500")
        self.root.configure(bg='#2c3e50')
        self.center_window()
        self.create_widgets()
    
    def center_window(self):
        self.root.update_idletasks()
        width = 550
        height = 500
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        # Header
        header = tk.Frame(self.root, bg='#34495e', height=120)
        header.pack(fill='x')
        header.pack_propagate(False)
        
        tk.Label(header, text="🔒 SRMS", font=('Arial', 22, 'bold'),
                bg='#34495e', fg='white').pack(pady=15)
        tk.Label(header, text="Secure Student Records Management System",
                font=('Arial', 11), bg='#34495e', fg='#3498db').pack()
        tk.Label(header, text="Database Security Project - Phase 2",
                font=('Arial', 9), bg='#34495e', fg='#95a5a6').pack(pady=5)
        
        # Form
        form = tk.Frame(self.root, bg='#2c3e50')
        form.pack(expand=True, fill='both', padx=50, pady=20)
        
        tk.Label(form, text="Username:", font=('Arial', 11, 'bold'),
                bg='#2c3e50', fg='white').pack(anchor='w', pady=(0, 5))
        self.username_entry = tk.Entry(form, font=('Arial', 12))
        self.username_entry.pack(fill='x', pady=(0, 15))
        self.username_entry.focus()
        
        tk.Label(form, text="Password:", font=('Arial', 11, 'bold'),
                bg='#2c3e50', fg='white').pack(anchor='w', pady=(0, 5))
        self.password_entry = tk.Entry(form, font=('Arial', 12), show='●')
        self.password_entry.pack(fill='x', pady=(0, 25))
        
        tk.Button(form, text="🔐 LOGIN", font=('Arial', 12, 'bold'),
                 bg='#27ae60', fg='white', command=self.login,
                 cursor='hand2', relief='flat', padx=20, pady=12).pack(fill='x')
        
        self.password_entry.bind('<Return>', lambda e: self.login())
        
        self.status_label = tk.Label(form, text="", font=('Arial', 10),
                                     bg='#2c3e50', fg='#e74c3c')
        self.status_label.pack(pady=10)
        
        # Hints
        hints = tk.Frame(self.root, bg='#2c3e50')
        hints.pack(pady=10)
        tk.Label(hints, text="💡 Quick Login: admin1 / Admin@123",
                font=('Arial', 9), bg='#2c3e50', fg='#95a5a6').pack()
    
    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not username or not password:
            self.status_label.config(text="⚠️ Please enter username and password")
            return
        
        self.status_label.config(text="🔄 Authenticating...", fg='#3498db')
        self.root.update()
        
        results, columns = self.db.execute_procedure('sp_Login', [username, password])
        
        if results and len(results) > 0:
            result_dict = dict(zip(columns, results[0]))
            if result_dict.get('Result') == 'Success':
                user_info = {
                    'UserID': result_dict.get('UserID'),
                    'Username': result_dict.get('Username'),
                    'Role': result_dict.get('Role'),
                    'ClearanceLevel': result_dict.get('ClearanceLevel')
                }
                self.on_login_success(user_info)
            else:
                self.status_label.config(text=f"❌ {result_dict.get('Message', 'Login failed')}", fg='#e74c3c')
        else:
            self.status_label.config(text="❌ Invalid credentials", fg='#e74c3c')


class MainApplication:
    def __init__(self, root, db, user_info):
        self.root = root
        self.db = db
        self.user_info = user_info
        
        self.root.title(f"SRMS - {user_info['Role']} Dashboard")
        self.root.geometry("1400x850")
        self.root.configure(bg='#ecf0f1')
        
        # Add global security for classified data access
        if user_info['ClearanceLevel'] >= 3:
            self._setup_security_protections()
        
        self.create_widgets()
    
    def _setup_security_protections(self):
        """Setup comprehensive security protections for classified data"""
        # Block Print Screen key
        self.root.bind("<Print>", self._block_screenshot)
        
        # Block Alt+Print Screen (window screenshot)
        self.root.bind("<Alt-Print>", self._block_screenshot)
        
        # Block Windows+Shift+S (Snipping Tool) - may not work on all systems
        self.root.bind("<Control-Shift-s>", self._block_screenshot)
        self.root.bind("<Control-Shift-S>", self._block_screenshot)
        
        # Block F12 (developer tools in some apps)
        self.root.bind("<F12>", self._block_screenshot)
        
        # Add security watermark to title
        class_name = 'SECRET' if self.user_info['ClearanceLevel'] == 3 else 'TOP SECRET'
        current_title = self.root.title()
        self.root.title(f"🔒 {class_name} - {current_title}")
    
    def _block_screenshot(self, event=None):
        """Block screenshot attempts"""
        # Log security violation
        class_name = 'SECRET' if self.user_info['ClearanceLevel'] == 3 else 'TOP SECRET'
        logging.warning(f"BLOCKED: Screenshot attempt by user {self.user_info.get('Username', 'Unknown')} viewing {class_name} data")
        
        messagebox.showerror(
            "Security Violation",
            "🚫 SCREENSHOT BLOCKED\n\n"
            "You are viewing classified data.\n"
            "Screenshots and screen captures are PROHIBITED.\n\n"
            "This incident has been logged."
        )
        return "break"
    
    def create_widgets(self):
        # Header
        header = tk.Frame(self.root, bg='#34495e', height=70)
        header.pack(fill='x')
        header.pack_propagate(False)
        
        tk.Label(header, text=f"👤 {self.user_info['Username']} ({self.user_info['Role']})",
                font=('Arial', 13, 'bold'), bg='#34495e', fg='white').pack(side='left', padx=20, pady=20)
        
        clearance_color = {1: '#95a5a6', 2: '#f39c12', 3: '#e67e22', 4: '#e74c3c'}
        tk.Label(header, text=f"🔒 Clearance: Level {self.user_info['ClearanceLevel']} - {self.get_clearance_name(self.user_info['ClearanceLevel'])}",
                font=('Arial', 11, 'bold'), bg='#34495e', 
                fg=clearance_color.get(self.user_info['ClearanceLevel'], '#3498db')).pack(side='left', padx=10)
        
        tk.Button(header, text="🚪 Logout", font=('Arial', 10, 'bold'),
                 bg='#e74c3c', fg='white', command=self.logout,
                 cursor='hand2', relief='flat', padx=15, pady=8).pack(side='right', padx=20)
        
        # Content
        content = tk.Frame(self.root, bg='#ecf0f1')
        content.pack(fill='both', expand=True)
        
        # Sidebar
        sidebar = tk.Frame(content, bg='#2c3e50', width=240)
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)
        
        self.main_panel = tk.Frame(content, bg='#ecf0f1')
        self.main_panel.pack(side='right', fill='both', expand=True)
        
        self.create_navigation(sidebar)
        self.show_dashboard()
    
    def create_navigation(self, sidebar):
        tk.Label(sidebar, text="📋 NAVIGATION", font=('Arial', 12, 'bold'),
                bg='#2c3e50', fg='white').pack(pady=20)
        
        role = self.user_info['Role']
        
        self.nav_btn("📊 Dashboard", self.show_dashboard, sidebar)
        
        if role == 'Admin':
            self.nav_btn("👥 Manage Users", self.show_users, sidebar)
            self.nav_btn("📝 Role Requests", self.show_role_requests, sidebar)
            self.nav_btn("🎓 Manage Students", self.show_students, sidebar)
            self.nav_btn("📚 Manage Courses", self.show_courses, sidebar)
            self.nav_btn("✏️ Enter Grades", self.show_enter_grades, sidebar)
            self.nav_btn("📊 View Grades", self.show_grades, sidebar)
            self.nav_btn("📅 View Attendance", self.show_attendance, sidebar)
            self.nav_btn("👤 My Profile", self.show_profile, sidebar)
        
        elif role == 'Instructor':
            self.nav_btn("👤 My Profile", self.show_profile, sidebar)
            self.nav_btn("📚 My Courses", self.show_my_courses, sidebar)
            self.nav_btn("✏️ Enter Grades", self.show_enter_grades, sidebar)
            self.nav_btn("📊 View Grades", self.show_grades, sidebar)
            self.nav_btn("📅 Manage Attendance", self.show_attendance, sidebar)
        
        elif role == 'TA':
            self.nav_btn("👤 My Profile", self.show_profile, sidebar)
            self.nav_btn("📚 Assigned Courses", self.show_ta_courses, sidebar)
            self.nav_btn("📅 Manage Attendance", self.show_attendance, sidebar)
            self.nav_btn("🔄 Request Upgrade", self.show_role_request, sidebar)
        
        elif role == 'Student':
            self.nav_btn("👤 My Profile", self.show_profile, sidebar)
            self.nav_btn("📚 My Courses", self.show_student_courses, sidebar)
            self.nav_btn("📊 My Grades", self.show_my_grades, sidebar)
            self.nav_btn("📅 My Attendance", self.show_my_attendance, sidebar)
            self.nav_btn("🔄 Request Upgrade", self.show_role_request, sidebar)
        
        elif role == 'Guest':
            self.nav_btn("📚 Public Courses", self.show_public_courses, sidebar)
    
    def nav_btn(self, text, command, parent):
        btn = tk.Button(parent, text=text, font=('Arial', 10), bg='#34495e',
                       fg='white', command=command, cursor='hand2', relief='flat',
                       anchor='w', padx=20, pady=12)
        btn.pack(fill='x', padx=5, pady=2)
        btn.bind('<Enter>', lambda e: btn.config(bg='#3498db'))
        btn.bind('<Leave>', lambda e: btn.config(bg='#34495e'))
    
    def clear_panel(self):
        for widget in self.main_panel.winfo_children():
            widget.destroy()
    
    def show_dashboard(self):
        self.clear_panel()
        
        tk.Label(self.main_panel, text=f"🏠 {self.user_info['Role']} Dashboard",
                font=('Arial', 24, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=30)
        
        cards = tk.Frame(self.main_panel, bg='#ecf0f1')
        cards.pack(pady=20)
        
        self.card(cards, "🔒 Security Clearance", f"Level {self.user_info['ClearanceLevel']}",
                 self.get_clearance_name(self.user_info['ClearanceLevel']))
        self.card(cards, "👤 Current Role", self.user_info['Role'], "Active Account")
        self.card(cards, "✅ Login Status", "Authenticated", datetime.now().strftime("%H:%M:%S"))
        
        # Role-specific info
        info_frame = tk.Frame(self.main_panel, bg='white', relief='raised', bd=2)
        info_frame.pack(padx=50, pady=30, fill='both', expand=True)
        
        tk.Label(info_frame, text=f"📋 {self.user_info['Role']} Capabilities",
                font=('Arial', 16, 'bold'), bg='white', fg='#2c3e50').pack(pady=20)
        
        capabilities = self.get_role_capabilities()
        for cap in capabilities:
            cap_frame = tk.Frame(info_frame, bg='white')
            cap_frame.pack(fill='x', padx=30, pady=5)
            tk.Label(cap_frame, text="✓", font=('Arial', 12, 'bold'),
                    bg='white', fg='#27ae60').pack(side='left', padx=10)
            tk.Label(cap_frame, text=cap, font=('Arial', 11),
                    bg='white', fg='#2c3e50', anchor='w').pack(side='left', fill='x')
    
    def get_role_capabilities(self):
        caps = {
            'Admin': [
                "Full system access and control",
                "Manage all users and assign roles",
                "View and edit all grades (Secret level)",
                "View and manage all attendance records",
                "Process role upgrade requests",
                "Access to all student and course data"
            ],
            'Instructor': [
                "View own profile and edit information",
                "Enter and view grades for assigned courses (Secret level)",
                "Manage attendance for assigned courses",
                "View student information for assigned courses",
                "Access to Confidential and Secret level data"
            ],
            'TA': [
                "View own profile and edit information",
                "Manage attendance for assigned courses only",
                "View student data for assigned courses (Confidential)",
                "Cannot access grade information",
                "Request role upgrade to Instructor"
            ],
            'Student': [
                "View own profile (cannot edit)",
                "View own grades when published",
                "View own attendance records",
                "View enrolled courses",
                "Request role upgrade to TA or Instructor"
            ],
            'Guest': [
                "View public course information only",
                "No access to student or grade data",
                "Most restricted access level",
                "Cannot view any classified information"
            ]
        }
        return caps.get(self.user_info['Role'], [])
    
    def card(self, parent, title, value, subtitle):
        c = tk.Frame(parent, bg='white', relief='raised', bd=2)
        c.pack(side='left', padx=15, ipadx=35, ipady=25)
        tk.Label(c, text=title, font=('Arial', 11), bg='white', fg='#7f8c8d').pack()
        tk.Label(c, text=value, font=('Arial', 18, 'bold'), bg='white', fg='#2c3e50').pack(pady=8)
        tk.Label(c, text=subtitle, font=('Arial', 9), bg='white', fg='#95a5a6').pack()
    
    def get_clearance_name(self, level):
        return {1: "Unclassified", 2: "Confidential", 3: "Secret", 4: "Top Secret"}.get(level, "Unknown")
    
    def show_profile(self):
        self.clear_panel()
        
        tk.Label(self.main_panel, text="👤 My Profile",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        # Get profile data based on role
        if self.user_info['Role'] == 'Student':
            results, columns = self.db.execute_procedure('sp_ViewStudentProfile',
                                                         [self.get_student_id(), self.user_info['UserID'],
                                                          self.user_info['ClearanceLevel']])
        else:
            # For other roles, show basic user info
            results, columns = self.db.execute_query(
                f"SELECT Username, Role, ClearanceLevel, LastLogin FROM Users WHERE UserID = {self.user_info['UserID']}")
        
        profile_frame = tk.Frame(self.main_panel, bg='white', relief='raised', bd=2)
        profile_frame.pack(padx=50, pady=20, fill='both', expand=True)
        
        tk.Label(profile_frame, text="📋 Profile Information",
                font=('Arial', 16, 'bold'), bg='white', fg='#2c3e50').pack(pady=20)
        
        if results:
            for i, col in enumerate(columns):
                row = tk.Frame(profile_frame, bg='white')
                row.pack(fill='x', padx=40, pady=8)
                
                tk.Label(row, text=f"{col}:", font=('Arial', 11, 'bold'),
                        bg='white', fg='#34495e', width=20, anchor='w').pack(side='left')
                tk.Label(row, text=str(results[0][i]) if results[0][i] else 'N/A',
                        font=('Arial', 11), bg='white', fg='#2c3e50').pack(side='left', padx=20)
        
        # Add edit button for Admin, Instructor, TA
        if self.user_info['Role'] in ['Admin', 'Instructor', 'TA']:
            btn_frame = tk.Frame(profile_frame, bg='white')
            btn_frame.pack(pady=20)
            
            tk.Button(btn_frame, text="✏️ Edit Profile", command=self.edit_profile,
                     bg='#3498db', fg='white', font=('Arial', 11, 'bold'),
                     padx=25, pady=10, cursor='hand2', relief='flat').pack()
        
        # Classification notice
        if self.user_info['ClearanceLevel'] >= 2:
            notice = tk.Frame(profile_frame, bg='#fff3cd', relief='solid', bd=1)
            notice.pack(padx=40, pady=20, fill='x')
            tk.Label(notice, text=f"🔒 Classification: {self.get_clearance_name(self.user_info['ClearanceLevel'])}",
                    font=('Arial', 10, 'bold'), bg='#fff3cd', fg='#856404').pack(pady=10)
            tk.Label(notice, text="This information is protected. Copying and exporting is restricted.",
                    font=('Arial', 9), bg='#fff3cd', fg='#856404').pack(pady=5)
    
    def get_student_id(self):
        """Get student ID for current user"""
        results, _ = self.db.execute_query(
            f"SELECT StudentID FROM Student WHERE UserID = {self.user_info['UserID']}")
        return results[0][0] if results else None
    
    def edit_profile(self):
        """Edit profile for Admin, Instructor, TA"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Edit Profile")
        dialog.geometry("500x400")
        dialog.configure(bg='#ecf0f1')
        dialog.transient(self.root)
        dialog.grab_set()
        
        tk.Label(dialog, text="✏️ Edit Your Profile", font=('Arial', 18, 'bold'),
                bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        form = tk.Frame(dialog, bg='white', relief='raised', bd=2)
        form.pack(padx=30, pady=10, fill='both', expand=True)
        
        # Get current username
        results, _ = self.db.execute_query(
            f"SELECT Username FROM Users WHERE UserID = {self.user_info['UserID']}")
        current_username = results[0][0] if results else ""
        
        tk.Label(form, text="Username:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        username_entry = tk.Entry(form, font=('Arial', 11), width=30)
        username_entry.insert(0, current_username)
        username_entry.pack(pady=5)
        
        tk.Label(form, text="New Password (leave blank to keep current):", 
                font=('Arial', 11, 'bold'), bg='white').pack(pady=(15, 5))
        password_entry = tk.Entry(form, font=('Arial', 11), show='●', width=30)
        password_entry.pack(pady=5)
        
        tk.Label(form, text="Confirm New Password:", 
                font=('Arial', 11, 'bold'), bg='white').pack(pady=(10, 5))
        confirm_entry = tk.Entry(form, font=('Arial', 11), show='●', width=30)
        confirm_entry.pack(pady=5)
        
        def save_changes():
            new_username = username_entry.get().strip()
            new_password = password_entry.get()
            confirm_password = confirm_entry.get()
            
            if not new_username:
                messagebox.showerror("Error", "Username cannot be empty", parent=dialog)
                return
            
            # If password is being changed, validate it
            if new_password:
                if new_password != confirm_password:
                    messagebox.showerror("Error", "Passwords do not match", parent=dialog)
                    return
                
                if len(new_password) < 6:
                    messagebox.showerror("Error", "Password must be at least 6 characters", parent=dialog)
                    return
                
                # Update username and password
                try:
                    cursor = self.db.connection.cursor()
                    cursor.execute(
                        "UPDATE Users SET Username = ?, PasswordHash = HASHBYTES('SHA2_256', ?) WHERE UserID = ?",
                        (new_username, new_password, self.user_info['UserID'])
                    )
                    cursor.commit()
                    messagebox.showinfo("Success", "Profile updated successfully!\nPlease login again with your new credentials.", parent=dialog)
                    dialog.destroy()
                    self.logout()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to update profile:\n{str(e)}", parent=dialog)
            else:
                # Update username only
                try:
                    cursor = self.db.connection.cursor()
                    cursor.execute(
                        "UPDATE Users SET Username = ? WHERE UserID = ?",
                        (new_username, self.user_info['UserID'])
                    )
                    cursor.commit()
                    self.user_info['Username'] = new_username
                    messagebox.showinfo("Success", "Username updated successfully!", parent=dialog)
                    dialog.destroy()
                    self.show_profile()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to update username:\n{str(e)}", parent=dialog)
        
        btn_frame = tk.Frame(form, bg='white')
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="💾 Save Changes", command=save_changes, bg='#27ae60',
                 fg='white', font=('Arial', 11, 'bold'), padx=25, pady=10,
                 cursor='hand2', relief='flat').pack(side='left', padx=5)
        tk.Button(btn_frame, text="❌ Cancel", command=dialog.destroy, bg='#95a5a6',
                 fg='white', font=('Arial', 11, 'bold'), padx=25, pady=10,
                 cursor='hand2', relief='flat').pack(side='left', padx=5)
    
    def show_users(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="👥 User Management",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        tk.Button(self.main_panel, text="➕ Add New User", font=('Arial', 11, 'bold'),
                 bg='#27ae60', fg='white', command=self.add_user_dialog,
                 cursor='hand2', relief='flat', padx=25, pady=12).pack(pady=10)
        
        try:
            cursor = self.db.connection.cursor()
            cursor.execute("SELECT UserID, Username, Role, ClearanceLevel, IsActive, LastLogin FROM Users ORDER BY UserID")
            results = cursor.fetchall()
            
            if results:
                tree = self.create_table(self.main_panel,
                                ['UserID', 'Username', 'Role', 'Clearance', 'Active', 'Last Login'],
                                results, classification=2)
            else:
                tk.Label(self.main_panel, text="No users found",
                        font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load users:\n{str(e)}")
    
    def add_user_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Add New User")
        dialog.geometry("500x550")
        dialog.configure(bg='#ecf0f1')
        dialog.transient(self.root)
        dialog.grab_set()
        
        tk.Label(dialog, text="➕ Create New User", font=('Arial', 18, 'bold'),
                bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        form = tk.Frame(dialog, bg='white', relief='raised', bd=2)
        form.pack(padx=30, pady=10, fill='both', expand=True)
        
        tk.Label(form, text="Username:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        username_entry = tk.Entry(form, font=('Arial', 11), width=30)
        username_entry.pack(pady=5)
        username_entry.focus()
        
        tk.Label(form, text="Password:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        password_entry = tk.Entry(form, font=('Arial', 11), show='●', width=30)
        password_entry.pack(pady=5)
        
        tk.Label(form, text="Role:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        role_var = tk.StringVar()
        role_combo = ttk.Combobox(form, textvariable=role_var, width=28,
                                 values=['Admin', 'Instructor', 'TA', 'Student', 'Guest'],
                                 state='readonly', font=('Arial', 11))
        role_combo.pack(pady=5)
        
        def save():
            username = username_entry.get().strip()
            password = password_entry.get()
            role = role_var.get()
            
            if not all([username, password, role]):
                messagebox.showerror("Error", "All fields are required", parent=dialog)
                return
            
            clearance = {'Admin': 4, 'Instructor': 3, 'TA': 2, 'Student': 1, 'Guest': 1}[role]
            results, cols = self.db.execute_procedure('sp_RegisterUser',
                                                      [username, password, role, clearance, self.user_info['UserID']])
            
            if results:
                result = dict(zip(cols, results[0]))
                if result.get('Result') == 'Success':
                    messagebox.showinfo("Success", f"User '{username}' created successfully!", parent=dialog)
                    dialog.destroy()
                    self.show_users()
                else:
                    messagebox.showerror("Error", result.get('ErrorMessage', 'Failed to create user'), parent=dialog)
            else:
                messagebox.showerror("Error", "Failed to create user", parent=dialog)
        
        btn_frame = tk.Frame(form, bg='white')
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="💾 Create User", command=save, bg='#27ae60',
                 fg='white', font=('Arial', 11, 'bold'), padx=25, pady=10,
                 cursor='hand2', relief='flat').pack(side='left', padx=5)
        tk.Button(btn_frame, text="❌ Cancel", command=dialog.destroy, bg='#95a5a6',
                 fg='white', font=('Arial', 11, 'bold'), padx=25, pady=10,
                 cursor='hand2', relief='flat').pack(side='left', padx=5)
    
    def show_role_requests(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📝 Role Upgrade Requests",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        results, columns = self.db.execute_procedure('sp_ViewPendingRoleRequests',
                                                     [self.user_info['UserID']])
        
        if not results:
            tk.Label(self.main_panel, text="✅ No pending requests",
                    font=('Arial', 14), bg='#ecf0f1', fg='#27ae60').pack(pady=50)
            return
        
        tree = self.create_table(self.main_panel, columns, results, classification=2)
        
        btn_frame = tk.Frame(self.main_panel, bg='#ecf0f1')
        btn_frame.pack(pady=15)
        
        def approve():
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Warning", "Please select a request")
                return
            request_id = tree.item(sel[0])['values'][0]
            self.db.execute_procedure('sp_ProcessRoleRequest',
                                     [request_id, self.user_info['UserID'], 'Approve', None])
            messagebox.showinfo("Success", "✓ Request approved successfully")
            self.show_role_requests()
        
        def deny():
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Warning", "Please select a request")
                return
            request_id = tree.item(sel[0])['values'][0]
            self.db.execute_procedure('sp_ProcessRoleRequest',
                                     [request_id, self.user_info['UserID'], 'Deny', None])
            messagebox.showinfo("Success", "✗ Request denied")
            self.show_role_requests()
        
        tk.Button(btn_frame, text="✓ Approve Request", command=approve, bg='#27ae60',
                 fg='white', font=('Arial', 11, 'bold'), padx=30, pady=12,
                 cursor='hand2', relief='flat').pack(side='left', padx=10)
        tk.Button(btn_frame, text="✗ Deny Request", command=deny, bg='#e74c3c',
                 fg='white', font=('Arial', 11, 'bold'), padx=30, pady=12,
                 cursor='hand2', relief='flat').pack(side='left', padx=10)
    
    def show_role_request(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="🔄 Request Role Upgrade",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        form = tk.Frame(self.main_panel, bg='white', relief='raised', bd=2)
        form.pack(padx=50, pady=20, fill='both', expand=True)
        
        tk.Label(form, text=f"Current Role: {self.user_info['Role']}",
                font=('Arial', 14, 'bold'), bg='white', fg='#2c3e50').pack(pady=15)
        
        tk.Label(form, text="Requested Role:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        role_var = tk.StringVar()
        
        roles = {'Student': ['TA', 'Instructor'], 'TA': ['Instructor']}.get(self.user_info['Role'], [])
        ttk.Combobox(form, textvariable=role_var, values=roles, state='readonly',
                    font=('Arial', 11), width=30).pack(pady=5)
        
        tk.Label(form, text="Reason (Required):", font=('Arial', 11, 'bold'), bg='white').pack(pady=10)
        reason_text = scrolledtext.ScrolledText(form, height=6, width=70, font=('Arial', 10))
        reason_text.pack(pady=5, padx=20)
        
        tk.Label(form, text="Additional Comments:", font=('Arial', 11, 'bold'), bg='white').pack(pady=10)
        comments_text = scrolledtext.ScrolledText(form, height=6, width=70, font=('Arial', 10))
        comments_text.pack(pady=5, padx=20)
        
        def submit():
            role = role_var.get()
            reason = reason_text.get('1.0', 'end-1c').strip()
            comments = comments_text.get('1.0', 'end-1c').strip()
            
            if not role or not reason:
                messagebox.showerror("Error", "Please select a role and provide a reason")
                return
            
            results, columns = self.db.execute_procedure('sp_SubmitRoleRequest',
                                                         [self.user_info['UserID'], role, reason, comments])
            
            if results:
                result = dict(zip(columns, results[0]))
                if result.get('Result') == 'Success':
                    messagebox.showinfo("Success", f"✓ {result.get('Message')}")
                    reason_text.delete('1.0', 'end')
                    comments_text.delete('1.0', 'end')
                    role_var.set('')
                else:
                    messagebox.showerror("Error", result.get('ErrorMessage'))
        
        tk.Button(form, text="📤 Submit Request", command=submit, bg='#3498db',
                 fg='white', font=('Arial', 12, 'bold'), padx=30, pady=12,
                 cursor='hand2', relief='flat').pack(pady=25)
    
    def show_students(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="🎓 Student Management",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        try:
            cursor = self.db.connection.cursor()
            cursor.execute("SELECT StudentID, FullName, Email, Department, ClearanceLevel FROM Student ORDER BY StudentID")
            results = cursor.fetchall()
            
            if results:
                tree = self.create_table(self.main_panel,
                                ['ID', 'Full Name', 'Email', 'Department', 'Clearance'],
                                results, classification=2)
                
                # Add classification notice
                notice = tk.Frame(self.main_panel, bg='#fff3cd', relief='solid', bd=1)
                notice.pack(padx=20, pady=10, fill='x')
                tk.Label(notice, text="🔒 Confidential Data - Export and copying restricted",
                        font=('Arial', 10, 'bold'), bg='#fff3cd', fg='#856404').pack(pady=8)
            else:
                tk.Label(self.main_panel, text="No students found",
                        font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load students:\n{str(e)}")
    
    def show_courses(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📚 Course Management",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        results, columns = self.db.execute_procedure('sp_ViewCourses',
                                                     [self.user_info['UserID'], self.user_info['Role']])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=1)
        else:
            tk.Label(self.main_panel, text="No courses available",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def show_grades(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📊 Grades Management",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        # Secret level warning - Enhanced
        warning = tk.Frame(self.main_panel, bg='#f8d7da', relief='solid', bd=3)
        warning.pack(padx=20, pady=10, fill='x')
        tk.Label(warning, text="🔒 SECRET LEVEL CLASSIFIED DATA 🔒",
                font=('Arial', 14, 'bold'), bg='#f8d7da', fg='#721c24').pack(pady=8)
        tk.Label(warning, text="⚠️ ALL EXPORT OPERATIONS BLOCKED: Copy • Print • Save • Screenshot • Right-Click",
                font=('Arial', 10, 'bold'), bg='#f8d7da', fg='#721c24').pack(pady=5)
        tk.Label(warning, text="Data is visible for authorized viewing only. Unauthorized export attempts will be logged.",
                font=('Arial', 9), bg='#f8d7da', fg='#721c24').pack(pady=(0, 8))
        
        results, columns = self.db.execute_procedure('sp_ViewGrades',
                                                     [None, None, self.user_info['UserID'],
                                                      self.user_info['ClearanceLevel']])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=3)
        else:
            tk.Label(self.main_panel, text="No grades available or insufficient clearance",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def show_enter_grades(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="✏️ Enter Student Grades",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        form = tk.Frame(self.main_panel, bg='white', relief='raised', bd=2)
        form.pack(padx=50, pady=20, fill='both', expand=True)
        
        tk.Label(form, text="📝 Grade Entry Form", font=('Arial', 16, 'bold'),
                bg='white', fg='#2c3e50').pack(pady=20)
        
        tk.Label(form, text="Student ID:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        student_entry = tk.Entry(form, font=('Arial', 11), width=30)
        student_entry.pack(pady=5)
        
        tk.Label(form, text="Course ID:", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        course_entry = tk.Entry(form, font=('Arial', 11), width=30)
        course_entry.pack(pady=5)
        
        tk.Label(form, text="Grade (0-100):", font=('Arial', 11, 'bold'), bg='white').pack(pady=5)
        grade_entry = tk.Entry(form, font=('Arial', 11), width=30)
        grade_entry.pack(pady=5)
        
        def submit():
            try:
                student_id = int(student_entry.get())
                course_id = int(course_entry.get())
                grade = float(grade_entry.get())
                
                if not (0 <= grade <= 100):
                    messagebox.showerror("Error", "Grade must be between 0 and 100")
                    return
                
                results, columns = self.db.execute_procedure('sp_EnterGrade',
                                                             [student_id, course_id, grade,
                                                              self.user_info['UserID'],
                                                              self.user_info['ClearanceLevel']])
                
                if results:
                    result = dict(zip(columns, results[0]))
                    if result.get('Result') == 'Success':
                        messagebox.showinfo("Success", f"✓ Grade {grade} entered successfully for Student {student_id}")
                        student_entry.delete(0, 'end')
                        course_entry.delete(0, 'end')
                        grade_entry.delete(0, 'end')
                        student_entry.focus()
                    else:
                        messagebox.showerror("Error", result.get('ErrorMessage'))
            except ValueError:
                messagebox.showerror("Error", "Please enter valid numeric values")
        
        tk.Button(form, text="💾 Submit Grade", command=submit, bg='#27ae60',
                 fg='white', font=('Arial', 12, 'bold'), padx=30, pady=12,
                 cursor='hand2', relief='flat').pack(pady=25)
        
        # Show recent grades
        tk.Label(form, text="Recent Grades Entered:", font=('Arial', 12, 'bold'),
                bg='white', fg='#2c3e50').pack(pady=10)
    
    def show_attendance(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📅 Attendance Management",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        # Secret level warning - Enhanced
        warning = tk.Frame(self.main_panel, bg='#f8d7da', relief='solid', bd=3)
        warning.pack(padx=20, pady=10, fill='x')
        tk.Label(warning, text="🔒 SECRET LEVEL CLASSIFIED DATA 🔒",
                font=('Arial', 14, 'bold'), bg='#f8d7da', fg='#721c24').pack(pady=8)
        tk.Label(warning, text="⚠️ ALL EXPORT OPERATIONS BLOCKED: Copy • Print • Save • Screenshot • Right-Click",
                font=('Arial', 10, 'bold'), bg='#f8d7da', fg='#721c24').pack(pady=5)
        tk.Label(warning, text="Attendance data is classified. View only - no export permitted.",
                font=('Arial', 9), bg='#f8d7da', fg='#721c24').pack(pady=(0, 8))
        
        results, columns = self.db.execute_procedure('sp_ViewAttendance',
                                                     [None, None, self.user_info['UserID'],
                                                      self.user_info['ClearanceLevel']])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=3)
        else:
            tk.Label(self.main_panel, text="No attendance records available",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def show_my_grades(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📊 My Grades",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        results, columns = self.db.execute_procedure('sp_StudentViewOwnGrades',
                                                     [self.user_info['UserID']])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=1)
            
            # Calculate average
            try:
                grades = [float(row[1]) for row in results if row[1]]
                if grades:
                    avg = sum(grades) / len(grades)
                    avg_frame = tk.Frame(self.main_panel, bg='#d4edda', relief='solid', bd=2)
                    avg_frame.pack(padx=20, pady=10, fill='x')
                    tk.Label(avg_frame, text=f"📈 Your Average Grade: {avg:.2f}",
                            font=('Arial', 14, 'bold'), bg='#d4edda', fg='#155724').pack(pady=10)
            except:
                pass
        else:
            tk.Label(self.main_panel, text="No grades available yet",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def show_my_attendance(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📅 My Attendance Records",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        results, columns = self.db.execute_procedure('sp_StudentViewOwnAttendance',
                                                     [self.user_info['UserID'], None])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=1)
            
            # Calculate attendance rate
            try:
                present = sum(1 for row in results if row[1] == 1 or str(row[1]).lower() == 'true')
                total = len(results)
                rate = (present / total * 100) if total > 0 else 0
                
                rate_frame = tk.Frame(self.main_panel, bg='#d1ecf1', relief='solid', bd=2)
                rate_frame.pack(padx=20, pady=10, fill='x')
                tk.Label(rate_frame, text=f"📊 Attendance Rate: {rate:.1f}% ({present}/{total} classes)",
                        font=('Arial', 14, 'bold'), bg='#d1ecf1', fg='#0c5460').pack(pady=10)
            except:
                pass
        else:
            tk.Label(self.main_panel, text="No attendance records available",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def show_my_courses(self):
        self.show_courses()
    
    def show_ta_courses(self):
        self.show_courses()
    
    def show_student_courses(self):
        self.show_courses()
    
    def show_public_courses(self):
        self.clear_panel()
        tk.Label(self.main_panel, text="📚 Available Courses (Public Information)",
                font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=20)
        
        results, columns = self.db.execute_procedure('sp_ViewCourses',
                                                     [self.user_info['UserID'], 'Guest'])
        
        if results:
            self.create_table(self.main_panel, columns, results, classification=1)
        else:
            tk.Label(self.main_panel, text="No courses available",
                    font=('Arial', 12), bg='#ecf0f1', fg='#7f8c8d').pack(pady=50)
    
    def create_table(self, parent, columns, data, classification=1):
        """Create a secure table with copy/export restrictions based on classification"""
        
        # Add classification banner for Secret/Top Secret data
        if classification >= 3:
            banner_color = '#f8d7da' if classification == 3 else '#721c24'
            text_color = '#721c24' if classification == 3 else '#ffffff'
            class_name = 'SECRET' if classification == 3 else 'TOP SECRET'
            
            banner = tk.Frame(parent, bg=banner_color, relief='solid', bd=3)
            banner.pack(padx=20, pady=(10, 0), fill='x')
            
            tk.Label(banner, text=f"🔒 {class_name} CLASSIFIED DATA 🔒",
                    font=('Arial', 14, 'bold'), bg=banner_color, fg=text_color).pack(pady=8)
            
            warning_frame = tk.Frame(parent, bg='#fff3cd', relief='solid', bd=2)
            warning_frame.pack(padx=20, pady=(5, 0), fill='x')
            
            warnings = [
                "⛔ COPYING is BLOCKED",
                "⛔ EXPORTING is BLOCKED", 
                "⛔ PRINTING is BLOCKED",
                "⛔ SAVING is BLOCKED",
                "⛔ RIGHT-CLICK is DISABLED"
            ]
            
            warning_text = "  |  ".join(warnings)
            tk.Label(warning_frame, text=warning_text,
                    font=('Arial', 9, 'bold'), bg='#fff3cd', fg='#856404').pack(pady=6)
        
        frame = tk.Frame(parent, bg='white', relief='raised', bd=2)
        frame.pack(padx=20, pady=10, fill='both', expand=True)
        
        # Use SecureTreeview for classified data
        if classification >= 3:
            tree = SecureTreeview(frame, classification_level=classification,
                                 columns=columns, show='headings', height=18)
        else:
            tree = ttk.Treeview(frame, columns=columns, show='headings', height=18)
        
        # Configure columns
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=max(120, len(str(col)) * 10))
        
        # Insert data
        for row in data:
            tree.insert('', 'end', values=row)
        
        tree.pack(side='left', fill='both', expand=True)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        
        # Record count with classification indicator
        count_text = f"📊 Total Records: {len(data)}"
        if classification >= 3:
            class_name = 'SECRET' if classification == 3 else 'TOP SECRET'
            count_text += f"  |  🔒 Classification: {class_name}"
        
        count_label = tk.Label(parent, text=count_text,
                              font=('Arial', 10, 'bold' if classification >= 3 else 'normal'), 
                              bg='#ecf0f1', 
                              fg='#e74c3c' if classification >= 3 else '#7f8c8d')
        count_label.pack(pady=5)
        
        # Add watermark overlay for classified data
        if classification >= 3:
            watermark = tk.Label(parent, 
                               text=f"{'SECRET' if classification == 3 else 'TOP SECRET'}\nNO EXPORT",
                               font=('Arial', 48, 'bold'),
                               fg='#d3d3d3',  # Light gray for subtle watermark
                               bg='#ecf0f1')
            watermark.place(relx=0.5, rely=0.5, anchor='center')
            watermark.lift()
            # Make watermark non-interactive
            watermark.bind('<Button-1>', lambda e: 'break')
        
        return tree
    
    def logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
            start_application()


def start_application():
    root = tk.Tk()
    db = DatabaseConnection()
    
    if not db.connect():
        root.destroy()
        return
    
    def on_login_success(user_info):
        root.destroy()
        main_root = tk.Tk()
        MainApplication(main_root, db, user_info)
        main_root.mainloop()
    
    LoginWindow(root, db, on_login_success)
    root.mainloop()


if __name__ == "__main__":
    start_application()
